create
  definer = kingshard@`%` procedure test()
BEGIN
    DECLARE objectid VARCHAR(32);
    DECLARE mpn VARCHAR(32);
    DECLARE mfg VARCHAR(32);
		select objectid,mpn,mfg  from myinfodetail limit 1 into objectid,mpn,mfg;

  END;


create
  definer = kingshard@`%` procedure createTable251()
BEGIN 
				DECLARE `@num` INT(11);
				DECLARE `@tableName` VARCHAR(250);
        DECLARE `@i` INT(11);     
        DECLARE `@createSql` VARCHAR(2560); 
        DECLARE `@createIndexSql1` VARCHAR(2560);     
        DECLARE `@createIndexSql2` VARCHAR(2560);
        DECLARE `@createIndexSql3` VARCHAR(2560);
        DECLARE `@j` VARCHAR(10);

				SET `@num`=6;
				-- SET `@tableName`=tt_additional_resources;
        SET `@i`=0; 
        WHILE  0< `@num` DO   
        
          IF `@i` < 10 THEN
             SET `@j` = CONCAT("000",`@i`);
          ELSE
             SET `@j` = CONCAT("00",`@i`);
          END IF;
        
    
                            -- `M_ID` bigint AUTO_INCREMENT PRIMARY KEY NOT NULL,
                            -- 创建表        
--                             SET @createSql = CONCAT('CREATE TABLE IF NOT EXISTS tt_price_now_',`@j`,'(
--   `objectid` char(32) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
--   `price_json` varchar(2048) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
-- 	`creattime` timestamp(0) NOT NULL DEFAULT CURRENT_TIMESTAMP(0) ON UPDATE CURRENT_TIMESTAMP(0),
-- 	`updatetime` timestamp(0) NOT NULL DEFAULT CURRENT_TIMESTAMP(0) ON UPDATE CURRENT_TIMESTAMP(0),
-- 	`obligate1` varchar(1024) CHARACTER SET utf8 COLLATE utf8_general_ci,
-- 	`batchno` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci,
--   PRIMARY KEY (`objectid`) USING BTREE
-- ) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;
-- '                            );
-- 														
-- 													PREPARE stmt FROM @createSql; 
--                           EXECUTE stmt;   
--        SET @alterColumn = CONCAT('alter table tt_interest_',`@j`,' CHANGE man  mfr VARCHAR(255);');
--               PREPARE stmt FROM @alterColumn; 
--               EXECUTE stmt;    
-- 


-- 														SET @alterT =CONCAT('ALTER TABLE  tt_price_now_',`@j`,' modify column `creattime` timestamp(0) NOT NULL DEFAULT CURRENT_TIMESTAMP(0);');
-- 													PREPARE stmt2 FROM @alterT; 
--                            EXECUTE stmt2; 
-- 修改列的长度
-- 						SET @alterT1 =CONCAT('ALTER TABLE  tt_price_',`@j`,' modify column `price_json` VARCHAR(2048);');
-- 									PREPARE stmt3 FROM @alterT1; 
--                            EXECUTE stmt3; 
-- 														SET @alterT =CONCAT('ALTER TABLE  tt_mytask_',`@j`,' modify column `cookie` mediumtext;');
-- 													PREPARE stmt2 FROM @alterT; 
--                            EXECUTE stmt2;  
-- 													 SET @alterPT =CONCAT('ALTER TABLE  tt_myprioritytask_',`@j`,' modify column `cookie` mediumtext;');
-- 													PREPARE stmtP2 FROM @alterPT; 
--                            EXECUTE stmtP2; 
-- 													SET @delectT =CONCAT('DROP TABLE IF EXISTS tt_detailedinfo_',`@j`,';');
-- 														PREPARE stmt1 FROM @delectT; 
--                            EXECUTE stmt1;   
-- 														
--                            PREPARE stmt FROM @createSql; 
--                            EXECUTE stmt;                             
                        
                            -- 创建索引    
                           SET @createIndexSql1  = CONCAT('create index `index_detail_id` on tt_stock_',`@j`,'(`detail_id`);');
                           PREPARE stmt FROM @createIndexSql1; 
                           EXECUTE stmt; 
--  SET @createIndexSql1  = CONCAT('create index `mpn_index` on tt_detailedinfo_',`@j`,'(`mpn`);');
--                            PREPARE stmt FROM @createIndexSql1; 
--                            EXECUTE stmt; 
														-- 添加列stock_to_price varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '库存与价格的对应关系',
-- 														SET @addColumn = CONCAT('alter table tt_urllist_',`@j`, ' add column  `domain` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL;');
-- 														PREPARE stmt FROM @addColumn; 
-- 														
-- 														SET @createIndexSql1  = CONCAT('create index `index_domain` on tt_urllist_',`@j`,'(`domain`);');
--                            PREPARE stmt FROM @createIndexSql1; 
--                            EXECUTE stmt; 
--                            EXECUTE stmt; 
-- 													 SET @addColumn1 = CONCAT('alter table tt_stock_',`@j`, ' add column stock_to_price varchar(1024) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL;');
-- 														PREPARE stmt FROM @addColumn1; 
--                            EXECUTE stmt; 
														-- 添加 updatetime 
-- 														SET @addColumn = CONCAT('alter table tt_stock_now_',`@j`, ' add statue int(11) NOT NULL DEFAULT 0;');
-- 														PREPARE stmt FROM @addColumn; 
--                            EXECUTE stmt; 
-- 
-- 修改列名

--  														SET @changeColumn = CONCAT('alter table tt_substitute_',`@j`, ' change column manhref mfrhref VARCHAR(255);');
-- 														PREPARE  stmt FROM @changeColumn; 
--  														EXECUTE stmt;

-- 	SET @addColumn = CONCAT('alter table t_stock_',`@j`, ' add stock_to_price VARCHAR(1024) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL;');
-- 														PREPARE stmt FROM @addColumn; 
--                            EXECUTE stmt; 

SET `@i`= `@i`+1; 
SET `@num`=`@num`-1;
END WHILE;
END;

